const { app, BrowserWindow, shell, ipcMain } = require("electron");
const path = require("path");
const { spawn } = require("child_process");
const http = require("http");

const PREFERRED_PORT = 7890;
let resolvedPort = null;
let serverProcess = null;
let mainWindow = null;
let debugWindow = null;

if (require("electron-squirrel-startup")) {
  app.quit();
}

function getFrontendIndex() {
  if (process.resourcesPath) {
    return path.join(process.resourcesPath, "frontend", "index.html");
  }
  return path.join(__dirname, "..", "resources", "frontend", "index.html");
}

function getFrontendBaseUrl() {
  if (process.resourcesPath) {
    return `file://${path.join(process.resourcesPath, "frontend")}/`;
  }
  return `file://${path.join(__dirname, "..", "resources", "frontend")}/`;
}

function startServer() {
  return new Promise((resolve, reject) => {
    const serverBundle = path.join(__dirname, "server-bundle.cjs");
    const sqlitePath = path.join(app.getPath("userData"), "poker.db");

    serverProcess = spawn(process.execPath, [serverBundle], {
      env: {
        ...process.env,
        ELECTRON_RUN_AS_NODE: "1",
        PORT: String(PREFERRED_PORT),
        SQLITE_DB_PATH: sqlitePath,
        STATIC_DIR: "",
      },
      stdio: ["ignore", "pipe", "pipe"],
    });

    let stdoutBuf = "";
    let settled = false;
    const failTimer = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error("Server did not start in time"));
      }
    }, 20000);

    serverProcess.stdout.on("data", (data) => {
      const text = data.toString();
      stdoutBuf += text;
      process.stdout.write("[server] " + text);
      const match = stdoutBuf.match(/SERVER_READY:(\d+)/);
      if (match && !settled) {
        settled = true;
        clearTimeout(failTimer);
        resolvedPort = parseInt(match[1], 10);
        resolve(resolvedPort);
      }
    });

    serverProcess.stderr.on("data", (data) => {
      process.stderr.write("[server] " + data.toString());
    });

    serverProcess.on("exit", (code) => {
      serverProcess = null;
      if (!settled) {
        settled = true;
        clearTimeout(failTimer);
        reject(new Error(`Server exited early with code ${code}`));
      }
    });
  });
}

function waitForServer(port, timeout = 15000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    function attempt() {
      http.get(`http://localhost:${port}/api/healthz`, (res) => {
        if (res.statusCode === 200) resolve(true);
        else retry();
      }).on("error", retry);
    }
    function retry() {
      if (Date.now() - start > timeout) {
        reject(new Error(`Server on port ${port} did not respond in time`));
        return;
      }
      setTimeout(attempt, 300);
    }
    attempt();
  });
}

function showLoadingScreen(win) {
  win.webContents.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: "Microsoft Sans Serif", Tahoma, sans-serif;
          background: radial-gradient(ellipse at center, #1a5c32 0%, #0d3319 70%, #061a0d 100%);
          color: #e8d5a0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          gap: 18px;
        }
        h2 { font-size: 22px; letter-spacing: 1px; }
        p { font-size: 12px; opacity: 0.6; }
        .dots { font-size: 20px; animation: pulse 1.2s infinite; }
        @keyframes pulse { 0%,100%{opacity:.3} 50%{opacity:1} }
      </style>
    </head>
    <body>
      <h2>Poker</h2>
      <div class="dots">● ● ●</div>
      <p>Starting local server...</p>
    </body>
    </html>
  `)}`);
}

function showDebugWindow(title, message, details = "") {
  if (debugWindow) {
    debugWindow.close();
  }
  debugWindow = new BrowserWindow({
    width: 980,
    height: 720,
    title: "Poker Startup Error",
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  debugWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`
    <!DOCTYPE html>
    <html>
    <body style="font-family:Segoe UI,Arial,sans-serif;background:#111;color:#f3d7a3;padding:24px;line-height:1.5">
      <h1 style="color:#ffb4a8;margin:0 0 12px">${title}</h1>
      <pre style="white-space:pre-wrap;background:#1b1b1b;padding:16px;border-radius:8px;border:1px solid #333">${message}</pre>
      <pre style="white-space:pre-wrap;background:#1b1b1b;padding:16px;border-radius:8px;border:1px solid #333">${details}</pre>
    </body>
    </html>
  `)}`);
  debugWindow.on("closed", () => {
    debugWindow = null;
  });
}

async function createWindow(port) {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    title: "Poker",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
      partition: "persist:poker-desktop",
    },
    backgroundColor: "#0d3319",
    show: false,
  });

  mainWindow.once("ready-to-show", () => mainWindow.show());

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith("http://localhost") && !url.startsWith("http://127.")) {
      shell.openExternal(url);
      return { action: "deny" };
    }
    return { action: "allow" };
  });

  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith("http://") && !url.startsWith("https://")) event.preventDefault();
  });

  showLoadingScreen(mainWindow);

  try {
    await waitForServer(port);
    mainWindow.loadURL(`http://localhost:${port}`);
  } catch (err) {
    console.error("[main] Failed to connect to server:", err);
    showDebugWindow("Server connection failed", err.message, String(err.stack || ""));
    try {
      await mainWindow.loadURL(getFrontendBaseUrl());
    } catch (fileErr) {
      console.error("[main] Failed to load local frontend:", fileErr);
      showDebugWindow("Frontend load failed", fileErr.message, String(fileErr.stack || ""));
      mainWindow.webContents.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`
        <!DOCTYPE html>
        <html>
        <body style="font-family:Microsoft Sans Serif,Tahoma,sans-serif;background:#0d3319;color:#e8d5a0;display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;gap:12px;">
          <h2>Failed to start Poker</h2>
          <p>The local UI could not be loaded.</p>
        </body>
        </html>
      `)}`);
    }
  }
}

ipcMain.handle("navigate-to", (_event, url) => {
  if (mainWindow && typeof url === "string" && url.startsWith("http://")) {
    mainWindow.loadURL(url);
  }
});

ipcMain.handle("go-home", () => {
  if (mainWindow && resolvedPort) {
    mainWindow.loadURL(`http://localhost:${resolvedPort}`);
  }
});

app.whenReady().then(async () => {
  try {
    const port = await startServer();
    await createWindow(port);
  } catch (err) {
    console.error("[main] Server startup failed:", err);
    showDebugWindow("Server startup failed", err.message, String(err.stack || ""));
    app.quit();
    return;
  }

  app.on("activate", async () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      await createWindow(resolvedPort || PREFERRED_PORT);
    }
  });
});

app.on("window-all-closed", () => {
  if (serverProcess) {
    serverProcess.kill("SIGTERM");
    serverProcess = null;
  }
  app.quit();
});

app.on("before-quit", () => {
  if (serverProcess) {
    serverProcess.kill("SIGTERM");
    serverProcess = null;
  }
});